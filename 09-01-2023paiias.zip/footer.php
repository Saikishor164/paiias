<!-- <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>
<body>
<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h3>About Us</h3>
                <p>Your description about the website or company.</p>
            </div>
            <div class="col-md-6">
                <h3>Contact Us</h3>
                <p>
                    <br> </p>
            </div>
        </div>
        <hr>
        <p class="text-center">&copy; 2023 Your Website. All rights reserved.</p>
    </div>
</footer>
</body>
</html> -->


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>Your Website</title>
    <style>
        /* Add any custom CSS here if needed */
    </style>
</head>
<body>
    <!-- <div class="wrapper"> -->
        <!-- Your page content here -->

        <!-- Sticky Footer -->
        <footer class="footer ">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <h3>About Us</h3>
                        <p>Your description about the website or company.</p>
                    </div>
                    <div class="col-md-6">
                        <h3>Contact Us</h3>
                        <p>Email: contact@example.com<br>
                        Phone: (123) 456-7890</p>
                    </div>
                </div>
                <hr>
                <p class="text-center">&copy; 2023 Your Website. All rights reserved.</p>
            </div>
        </footer>
    <!-- </div> -->
</body>
</html>

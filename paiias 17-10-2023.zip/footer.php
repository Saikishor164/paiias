<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>PAIIAS</title>
    <style>
        /* Add any custom CSS here if needed */
    </style>
</head>
<body>
    <!-- <div class="wrapper"> -->
        <!-- Your page content here -->

        <!-- Sticky Footer -->
        <footer class="footer ">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <h3>Address</h3>
                        <p>P A INAMDAR IAS COACHING INSTITUTE 
                <br> 2390-B, K.B, Hidayatullah Road, Azam Campus, 
                Pune Cantonment, Camp, Pune, Maharashtra - 411001
</p>
                    </div>
                    <div class="col-md-6">
                        <h3>Contact Us</h3>
                        <p>Email: pai-ias@azamcampus.org<br>
                        </p>
                    </div>
                </div>
                <hr>


                





                <p class="text-center h6">Copyright &copy; 2023 | P. A. Inamdar IAS Coaching Institute, Pune | Devloped by AZAM I.T</p>
            </div>
        </footer>
    <!-- </div> -->
</body>
</html>
